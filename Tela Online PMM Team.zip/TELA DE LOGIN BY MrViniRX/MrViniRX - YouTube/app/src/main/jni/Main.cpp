#include <sys/types.h>
#include <pthread.h>
#include <jni.h>
#include <unistd.h>
#include "Logger.h"

//Serve Do Painel
extern "C" JNIEXPORT jstring
JNICALL
Java_com_example_loginform2_Auth_Title(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(("https://hyupaimods.net/gamefire/trial.php"));
}
