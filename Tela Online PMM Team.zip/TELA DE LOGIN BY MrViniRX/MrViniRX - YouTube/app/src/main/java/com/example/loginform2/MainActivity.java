package com.example.loginform2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.ViewGroup;
import android.content.res.AssetManager;
import java.io.IOException;
import android.graphics.drawable.Drawable;
import java.io.InputStream;

public class MainActivity extends Activity {
	
	public static Typeface StruckBase;
    public static String Struck_ = "fonts/HAPPY.otf";

	final public String sGameActivity = "com.dts.freefireth.FFMainActivity";
    Prefs prefs;

	private InputStream open;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.loadLibrary("Madame");
        if(!checkVPN(this)) {
            Init();
        } else {
            Toast.makeText(MainActivity.this, "no vpn", Toast.LENGTH_LONG).show();
        }
    }

    public void Init() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(false);
        alert.setView(revendedores());
        alert.setTitle("Alerta! Não Caia em Golpes!!!");
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Login();
                }
            });
        alert.create().show();

    }

    public static boolean checkVPN(Context c) {
        ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getNetworkInfo(ConnectivityManager.TYPE_VPN).isConnectedOrConnecting();
    }

    public void Login() {

        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setCancelable(false);
		// getWindow().setFlags(8192, 8192);
        alert.setView(dialog_login_nexus());
        alert.create().show();
    }

    public static GradientDrawable botoes(Context context) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setStroke(5, Color.parseColor("#d500f9"));
        gradientDrawable.setCornerRadius(TypedValue.applyDimension(1, 5.0f, context.getResources().getDisplayMetrics()));
        return gradientDrawable;
    }

    private View dialog_login_nexus() {
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setBackgroundColor(Color.parseColor("#292828"));
        linearLayout.setOrientation(1);
		try {
            open = getAssets().open("script.jfif");
        } catch (IOException e) {
            e.printStackTrace();
            open = null;
        }
        linearLayout.setBackground(Drawable.createFromStream(open, null));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(dp(40), dp(40));
        layoutParams.gravity = 5;
        Button button = new Button(this);
        button.setTag("btnFechar");
        button.setLayoutParams(layoutParams);
		button.setText((CharSequence)"X");
        button.setBackgroundColor(Color.parseColor((String)"#ff0018"));
        button.setTextColor(Color.parseColor((String)"#ffffff"));
        button.setTypeface(null, 1);
        button.setTextSize(2, 20.0f);
        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finishAffinity();
                }
            });
		StruckBase = Typeface.createFromAsset((AssetManager)this.getBaseContext().getAssets(), (String)Struck_);
        TextView textView = new TextView(this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
        textView.setLayoutParams(layoutParams2);
        textView.setText((CharSequence)"PMM Team");
        textView.setPadding(0, 5, 0, 5);
        textView.setGravity(1);
        textView.setTextColor(Color.parseColor((String)"#d500f9"));
        textView.setTextSize(20.0f);
        textView.setTypeface(StruckBase);
        final EditText editText = new EditText(this);
        editText.setTag("edtUsuario");
        editText.setHint("Usuário");
        editText.setTextColor(Color.parseColor((String)"#ffffff"));
        editText.setHintTextColor(Color.parseColor((String)"#ffffff"));
        layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams2.setMarginStart(dp(8));
        layoutParams2.topMargin = dp(16);
        layoutParams2.setMarginEnd(dp(8));
        editText.setLayoutParams(layoutParams2);
        final EditText editText2 = new EditText(this);
        editText2.setTag("edtSenha");
        editText2.setHint("Senha");
		editText2.setTextColor(Color.parseColor((String)"#ffffff"));
        editText2.setHintTextColor(Color.parseColor((String)"#ffffff"));
        layoutParams2.setMarginStart(dp(8));
        layoutParams2.topMargin = dp(16);
        layoutParams2.setMarginEnd(dp(8));
        editText2.setLayoutParams(layoutParams2);
        LinearLayout linearLayout2 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.weight = 1.0f;
        linearLayout2.setLayoutParams(layoutParams3);
        CheckBox checkBox = new CheckBox(this);
        checkBox.setTag("cbLembrar");
        layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.setMargins(dp(8), dp(8), 0, dp(8));
        checkBox.setLayoutParams(layoutParams2);
        checkBox.setText("Lembrar");
        checkBox.setTextColor(Color.parseColor((String)"#d500f9"));
        if( prefs.with(MainActivity.this).read("save").equals("1")) {
            editText.setText( prefs.with(MainActivity.this).read("USER_Sv"));
            editText2.setText( prefs.with(MainActivity.this).read("PASS_Sv"));
            checkBox.setChecked(true);
        } else {
            checkBox.setChecked(false);
        }
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        editText.setText( prefs.with(MainActivity.this).read("USER_Sv"));
                        editText2.setText( prefs.with(MainActivity.this).read("PASS_Sv"));
                        prefs.with(MainActivity.this).write("save", "1");

                    } else {
                        editText.setText("");
                        editText2.setText("");
                        prefs.with(MainActivity.this).write("save", "0");

                    }
                }
            });
        linearLayout2.addView(checkBox);
        LinearLayout linearLayout3 = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-1, -2);
        layoutParams4.weight = 1.0f;
        linearLayout3.setLayoutParams(layoutParams4);
        linearLayout3.setOrientation(1);
        Button button2 = new Button(this);
        button2.setTag("btnEntrar");
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, dp(40));
        layoutParams5.gravity = 5;
        layoutParams5.weight = 1.0f;
        layoutParams5.topMargin = dp(8);
        layoutParams5.rightMargin = dp(8);
        layoutParams5.bottomMargin = dp(8);
        button2.setLayoutParams(layoutParams5);
        button2.setText("Entrar");
        button2.setTextColor(Color.parseColor((String)"#d500f9"));
        button2.setTextSize(2, 12.0f);
        button2.setBackground(botoes(this));
        button2.setTypeface(null, Typeface.MONOSPACE.getStyle());
        button2.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    String user = editText.getText().toString().trim();
                    String pass = editText2.getText().toString().trim();
                    prefs.with(MainActivity.this).write("USER_Sv", user);
                    prefs.with(MainActivity.this).write("PASS_Sv", pass);

					new Auth(MainActivity.this).execute(new String[]{user, pass});

                }
            });
        linearLayout3.addView(button2);
        linearLayout.addView(button);
        linearLayout.addView(textView);
        linearLayout.addView(editText);
        linearLayout.addView(editText2);
        linearLayout.addView(linearLayout2);
        linearLayout.addView(linearLayout3);
        linearLayout3 = new LinearLayout(this);
        linearLayout3.setTag("ll_progress");
        layoutParams4 = new LinearLayout.LayoutParams(-1, -1);
        linearLayout3.setVisibility(8);
        linearLayout3.setBackgroundColor(Color.parseColor("#99FFFFFF"));
        linearLayout3.setOrientation(1);
        linearLayout3.setGravity(17);
        linearLayout3.setClickable(true);
        linearLayout3.setLayoutParams(layoutParams4);
        ProgressBar progressBar = new ProgressBar(this);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        linearLayout3.addView(progressBar);
        frameLayout.addView(linearLayout);
        frameLayout.addView(linearLayout3);
        return frameLayout;
    }

    private View revendedores() {
        ScrollView scrollView = new ScrollView((Context)this);
        scrollView.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1));
        LinearLayout linearLayout = new LinearLayout((Context)this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(this.dp(15), this.dp(15), this.dp(15), this.dp(15));
        linearLayout.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
        linearLayout.setVerticalScrollBarEnabled(true);
        linearLayout.setHorizontalScrollBarEnabled(true);
        linearLayout.setGravity(1);
        linearLayout.setOrientation(1);
        TextView textView = new TextView((Context)this);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.topMargin = this.dp(10);
        textView.setLayoutParams((ViewGroup.LayoutParams)layoutParams2);
        textView.setTypeface(null, 1);
        textView.setText((CharSequence)"DONOS E VENDEDORES OFICIAIS");
        TextView textView2 = new TextView((Context)this);
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.topMargin = this.dp(10);
        textView2.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
        textView2.setText((CharSequence)"Telegram Channel Oficial:");
        TextView textView3 = new TextView((Context)this);
        textView3.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        textView3.setText((CharSequence)"t.me/joinchat/RHoDSTU-rmA0MjNh");
        textView3.setClickable(true);
        textView3.setTag((Object)"txtTelegramCanal");
        textView3.setLinksClickable(true);
        textView3.setTextColor(Color.parseColor((String)"#820099"));
        TextView textView4 = new TextView((Context)this);
        new LinearLayout.LayoutParams((int)-2, (int)-2).topMargin = this.dp(10);
        textView4.setLayoutParams((ViewGroup.LayoutParams)layoutParams3);
        textView4.setText((CharSequence)"Discord Channel Oficial:");
        TextView textView5 = new TextView((Context)this);
        textView5.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        textView5.setText((CharSequence)"discord.gg/7k7z3a4Vh8");
        textView5.setClickable(true);
        textView5.setTag((Object)"txtDiscordCanal");
        textView5.setLinksClickable(true);
        textView5.setTextColor(Color.parseColor((String)"#820099"));
        TextView textView6 = new TextView((Context)this);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams4.topMargin = this.dp(5);
        textView6.setLayoutParams((ViewGroup.LayoutParams)layoutParams4);
        textView6.setText((CharSequence)"clique no n\u00famero para entrar em contato:");
        TextView textView7 = new TextView((Context)this);
        LinearLayout.LayoutParams layoutParams5 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams5.topMargin = this.dp(10);
        textView7.setLayoutParams((ViewGroup.LayoutParams)layoutParams5);
        textView7.setText((CharSequence)"PATOLINO BR");
        TextView textView8 = new TextView((Context)this);
        textView8.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        textView8.setText((CharSequence)"instagram.com/patolinobr");
        textView8.setClickable(true);
        textView8.setTag((Object)"txtPatoInstagram");
        textView8.setLinksClickable(true);
        textView8.setTextColor(Color.parseColor((String)"#820099"));
        TextView textView9 = new TextView((Context)this);
        LinearLayout.LayoutParams layoutParams6 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams6.topMargin = this.dp(10);
        textView9.setLayoutParams((ViewGroup.LayoutParams)layoutParams6);
        textView9.setText((CharSequence)"MADAME MODZ");
        TextView textView10 = new TextView((Context)this);
        textView10.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        textView10.setText((CharSequence)"wa.me/5565999524152");
        textView10.setClickable(true);
        textView10.setTag((Object)"txtMadameNumero");
        textView10.setLinksClickable(true);
        textView10.setTextColor(Color.parseColor((String)"#820099"));
        TextView textView11 = new TextView((Context)this);
        textView11.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-2, -2));
        textView11.setText((CharSequence)"instagram.com/madamemodz");
        textView11.setClickable(true);
        textView11.setTag((Object)"txtMadameInstragram");
        textView11.setLinksClickable(true);
        textView11.setTextColor(Color.parseColor((String)"#820099"));
        linearLayout.addView((View)textView);
        linearLayout.addView((View)textView6);
        linearLayout.addView((View)textView2);
        linearLayout.addView((View)textView3);
        linearLayout.addView((View)textView4);
        linearLayout.addView((View)textView5);
        linearLayout.addView((View)textView7);
        linearLayout.addView((View)textView8);
        linearLayout.addView((View)textView9);
        linearLayout.addView((View)textView11);
        linearLayout.addView((View)textView10);
        scrollView.addView((View)linearLayout);
        return scrollView;
    }

    public View.OnClickListener clickvendedores (String url2) {

        final String url = url2;

        View.OnClickListener a = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        };
        return a;
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    private int getResID(String name, String type) {
        return getResources().getIdentifier(name, type, getPackageName());
    }
}





